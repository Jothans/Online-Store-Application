<?php
/* =-=-=-= Copyright © 2018 eMarket =-=-=-=  
  |    GNU GENERAL PUBLIC LICENSE v.3.0    |    
  |  https://github.com/musicman3/eMarket  |
  =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= */

?>

<div class="container-fluid mt-3 mb-3">
    <nav>
	<ol class="breadcrumb bg-light pt-2 pe-3 pb-2 ps-3 border rounded" id="breadcrumb"></ol>
    </nav>
</div>